function Footer() {
    return (
        <footer className="bg-dark p-3 fixed-bottom foo">
            <p className="text-secondary">All-round.ua</p>
        </footer>
    );
}

export default Footer;